import java.util.ArrayList;

public class Ex1_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> cores = new ArrayList<String>();
		
		cores.add("Azul");
		cores.add("Branco");
		cores.add("Preto");
		cores.add("Rosa");
		cores.add("Amarelo");
		
		System.out.println("Imprindo o ArrayList criado.\n");
		
		for(int i=0; i < cores.size(); i++) {
			System.out.println(cores.get(i));
		}
		
		cores.set(0, "Vermelho");
		
		System.out.println("\nImprimindo o ArrayList adionando Vermleho na 1� posi��o.\n");
		
		for(int i=0; i < cores.size(); i++) {
			System.out.println(cores.get(i));
		}
		
		cores.remove(2);
		
		System.out.println("\nImprimindo o ArrayList excluindo a 3� posi��o.\n");
		
		for(int i=0; i < cores.size(); i++) {
			System.out.println(cores.get(i));
		}
	}

}
