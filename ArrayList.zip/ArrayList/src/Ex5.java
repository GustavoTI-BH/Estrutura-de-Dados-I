import java.util.ArrayList;
import java.util.Scanner;

public class Ex5 {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		// TODO Auto-generated method stub
		
		Cliente cliente;
		
		ArrayList<Cliente> listaCliente = new ArrayList<Cliente>();
		
		while(true) {
			cliente = new Cliente();
			
			System.out.print("Digite o ID do Cliente: ");
			int id = input.nextInt();
			
			if(id < 0)
				break;
			
			cliente.setId(id);
			
			System.out.print("Digite o nome do Cliente: ");
			cliente.setNome(input.next());
			
			System.out.print("Digite a idade do Cliente: ");
			cliente.setIdade(input.nextInt());
			
			System.out.print("Digite o telefone do Cliente: ");
			cliente.setTelefone(input.nextInt());
			
			System.out.println("\n");
			
			listaCliente.add(cliente);
		}
		
		System.out.println("\n");
		
		for(int i=0; i < listaCliente.size(); i++) {
			
			cliente = listaCliente.get(i);
			
			System.out.println("ID: " + cliente.getId());
			System.out.println("Nome: " + cliente.getNome());
			System.out.println("Telefone: " + cliente.getTelefone());
			System.out.println("------------------------------\n");
		}
		
	}

}